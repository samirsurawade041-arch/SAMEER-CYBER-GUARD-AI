# SCG Android project

This is the Android Studio source project for the SCG app.

## What's included
- Your supplied SAMEER CYBER GUARD AI HTML prototype as the starting screen.
- SCG launcher icon.
- Android WebView wrapper.
- Native Android Text-to-Speech bridge.
- Native Android speech-recognition intent bridge.
- Runtime microphone permission request.

## Important current limitations
- This is a source project, NOT an APK.
- The chat responses, Cyber Terminal, labs, and two-device pairing remain prototype/demo behavior.
- The native speech recognition uses the device's configured speech recognition service and may require internet or an installed speech service.
- A true live AI backend, real Linux/Python runtime, security scanning, and consent-based remote support still need separate implementation and testing.
- No hidden access, credential extraction, or access to another device without its owner's explicit approval is implemented.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
Use Android Studio with JDK 17 and Android SDK Platform 35 installed.

## Phone-only cloud build (GitHub Actions)
1. Create a free GitHub account if you do not already have one.
2. In GitHub, create a new **public** repository named `SCG-Android` (public is simplest for GitHub Actions on a free account; do not upload secrets or private user data).
3. Extract this ZIP on your Android phone. In the repository, use **Add file > Upload files** and upload the extracted project contents, including the hidden `.github/workflows/build-apk.yml` folder. If the mobile browser hides dot-folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow from this file's project copy.
4. Open the repository's **Actions** tab, choose **Build SCG APK**, and tap **Run workflow** if it has not started automatically.
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `SCG-debug-APK`. Extract it and install `app-debug.apk`, allowing installation from that browser/files app when Android asks.

This workflow has been added but has NOT yet been executed. The APK is not built or tested until GitHub Actions reports success. A debug APK is for testing, not Play Store release.

## Cloud build workflow
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.
After the project is pushed to a GitHub repository's `main` branch, or after
manually running the workflow from the Actions tab, it attempts to build a
debug APK and upload it as an Actions artifact. This workflow has not yet
been run or verified; the first run may reveal dependency or Gradle issues.
